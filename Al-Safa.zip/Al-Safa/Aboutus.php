<?php include('header.php') ?>




<br><br>

 <div class="back_re">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="title">
                     <h2>About Us</h2>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- about -->
      <div class="about">
         <div class="container-fluid">
            <div class="row">
               <div class="col-md-5">
                  <div class="titlepage">
                    
                   <p>Al-Safa Printing Press has been working since 1999 for different kind of business owners, entrepreneurs, custom designs and professional marketing. Our printing services are intended to help you find custom products you need business cards, promotional marketing and more to create a look you love.<br><br>Al-Safa Printing Press are pleased to be a group of highly qualified and experienced individuals who work together as a team to improve the quality of the finished goods and our track record of accomplishment. Business cards, calendars, brochures, holders for brochures, catalogs, banners, and flyers, as well as printing, labels, hang tags, invitations, signs, and table tents, are examples of common promotional items.<br><br>We stand by everything we sell. So if you’re not satisfied, we’ll make it right.</p>
                     <a class="read_more" href="Javascript:void(0)"> Read More</a>
                  </div>
               </div>
               <div class="col-md-7">
                  <div class="about_img">
                     <figure><img src="assets_front/images/pics.jpg" alt="#"/></figure>
                  </div>
               </div>
            </div>
         </div>
      </div>











<?php include('footer.php') ?>