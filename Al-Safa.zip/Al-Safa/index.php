<?php include('header.php') ?>

<br><br>
<section class="banner_main">
         <div id="myCarousel" class="carousel slide banner" data-ride="carousel">
            <ol class="carousel-indicators">
               <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
               <li data-target="#myCarousel" data-slide-to="1"></li>
               <li data-target="#myCarousel" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
               <div class="carousel-item active">
                  <img class="first-slide" src="assets_front/images/my new pics.jpg" alt="First slide">
                  <div class="container">
                  </div>
               </div>
               <div class="carousel-item">
                  <img class="second-slide" src="assets_front/images/my new pics2.jpg" alt="Second slide">
               </div>
               <div class="carousel-item">
                  <img class="third-slide" src="assets_front/images/my new pics1.jpg" alt="Third slide">
               </div>
            </div>
            <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
            </a>
         </div>
      </section>
      <!-- end banner -->
      <!-- about -->
      <div class="about">
         <div class="container-fluid">
            <div class="row">
               <div class="col-md-5">
                  <div class="titlepage">
                     <h2>About Us</h2>
                     <p>For more than 20 years, Al-Safa Printing Press has worked for business owners, entrepreneurs and dreamers create custom designs and professional marketing. Our printing services are intended to help you find custom products you need business cards, promotional marketing and more to create a look you love.<br><br> Our designs can be used across multiple printed products, which makes it easier for you to create consistent, professional marketing.<br><br>We stand by everything we sell. So if you’re not satisfied, we’ll make it right.</p>
                     <a class="read_more" href="Aboutus.php"> Read More</a>
                  </div>
               </div>
               <div class="col-md-7">
                  <div class="about_img">
                     <figure><img src="assets_front/images/pics.jpg" alt="#"/></figure>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- end about -->
      <!-- our_room -->
      <div  class="our_room">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="titlepage">
                     <h2>Our Services</h2>
                     <p>Here are some services that we can provide:</p>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-4 col-sm-6">
                  <div id="serv_hover"  class="room">
                     <div class="room_img">
                        <figure><img src="assets_front/images/offset.jpg" alt="#"/></figure>
                     </div>
                     <div class="bed_room">
                        <h3>OFFSET PRINTING</h3>
                        <p>Offset printing is a widely used printing method that produces high-quality prints with sharp details and vibrant colors.</p>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6">
                  <div id="serv_hover"  class="room">
                     <div class="room_img">
                        <figure><img src="assets_front/images/digital.jpg" alt="#"/></figure>
                     </div>
                     <div class="bed_room">
                        <h3>DIGITAL PRINTING</h3>
                        <p>Digital printing services are a great way to create high-quality prints quickly and efficiently for marketing or personal prints.</p>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6">
                  <div id="serv_hover"  class="room">
                     <div class="room_img">
                        <figure><img src="assets_front/images/screen.jpg" alt="#"/></figure>
                     </div>
                     <div class="bed_room">
                        <h3>SCREEN PRINTING</h3>
                        <p>Screen printing method can be used on a variety of materials, including paper, fabric, and plastics, and can create designs with vivid colors. </p>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6">
                  <div id="serv_hover"  class="room">
                     <div class="room_img">
                        <figure><img src="assets_front/images/fabric1.jpg" alt="#"/></figure>
                     </div>
                     <div class="bed_room">
                        <h3>FABRIC PRINTING</h3>
                        <p>Fabric printing services are a great way to create custom textiles for a variety of purposes, such as clothing, home decor, and accessories.</p>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6">
                  <div id="serv_hover"  class="room">
                     <div class="room_img">
                        <figure><img src="assets_front/images/mugshirt.jpg" alt="#"/></figure>
                     </div>
                     <div class="bed_room">
                        <h3>SHIRT & MUG PRINTING</h3>
                        <p>Mug and shirt printing services offer a unique and customizable way to express your personality and promote your brand.</p>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6">
                  <div id="serv_hover"  class="room">
                     <div class="room_img">
                        <figure><img src="assets_front/images/packaging.jpg" alt="#"/></figure>
                     </div>
                     <div class="bed_room">
                        <h3>PACKAGING SOLUTIONS</h3>
                        <p>Packaging solutions can help businesses reinforce their brand image by creating packaging that aligns with their overall branding. </p>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6">
                  <div id="serv_hover"  class="room">
                     <div class="room_img">
                        <figure><img src="assets_front/images/general.jpg" alt="#"/></figure>
                     </div>
                     <div class="bed_room">
                        <h3>GENERAL ORDER SUPPLY</h3>
                        <p>General order suppliers include anything from stationery equipment to office supplies, cleaning supplies, and even industrial equipment.</p>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6">
                  <div id="serv_hover"  class="room">
                     <div class="room_img">
                        <figure><img src="assets_front/images/files.jpg" alt="#"/></figure>
                     </div>
                     <div class="bed_room">
                        <h3>FILES MANUFACTURING</h3>
                        <p>Manufacturing files typically contain important information related to the production process including quality control and various types of products.</p>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6">
                  <div id="serv_hover"  class="room">
                     <div class="room_img">
                        <figure><img src="assets_front/images/record.jpg" alt="#"/></figure>
                     </div>
                     <div class="bed_room">
                        <h3>RECORD & BINDING</h3>
                        <p>Office record archive and binding are essential for any organization that wants to keep its important documents organized and accessible.</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- end our_room -->
      <!-- gallery -->
      
      <div  class="gallery">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="titlepage">
                     <h2>Portfolio</h2>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-3 col-sm-6">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/images1.jpg" alt="#"/></figure>
                  </div>
               </div>
               <div class="col-md-3 col-sm-6">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/images2.jpg" alt="#"/></figure>
                  </div>
               </div>
               <div class="col-md-3 col-sm-6">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/images3.jpg" alt="#"/></figure>
                  </div>
               </div>
               <div class="col-md-3 col-sm-6">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/images4.jpg" alt="#"/></figure>
                  </div>
               </div>
               <div class="col-md-3 col-sm-6">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/images5.jpg" alt="#"/></figure>
                  </div>
               </div>
               <div class="col-md-3 col-sm-6">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/images6.jpg" alt="#"/></figure>
                  </div>
               </div>
               <div class="col-md-3 col-sm-6">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/images7.jpg" alt="#"/></figure>
                  </div>
               </div>
               <div class="col-md-3 col-sm-6">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/images8.jpg" alt="#"/></figure>
                  </div>
               </div>
            </div>
         </div>
      </div>

      <br><br><br>
      

         <div  class="gallery">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="titlepage">
                     <h2>Our Clients</h2>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-2 col-sm-5">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/logo1.jpg" alt="#"/></figure>
                  </div>
               </div>
               <div class="col-md-2 col-sm-5">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/logo2.jpg" alt="#"/></figure>
                  </div>
               </div>
               <div class="col-md-2 col-sm-5">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/logo3.jpg" alt="#"/></figure>
                  </div>
               </div>
               <div class="col-md-2 col-sm-5">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/logo4.jpg" alt="#"/></figure>
                  </div>
               </div>
                <div class="col-md-2 col-sm-5">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/logo5.jpg" alt="#"/></figure>
                  </div>
               </div>
                <div class="col-md-2 col-sm-5">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/logo6.jpg" alt="#"/></figure>
                  </div>
               </div>
                <div class="col-md-2 col-sm-5">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/logo7.jpg" alt="#"/></figure>
                  </div>
               </div>
                 <div class="col-md-2 col-sm-5">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/logo8.jpg" alt="#"/></figure>
                  </div>
               </div>
               <div class="col-md-2 col-sm-5">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/logo9.jpg" alt="#"/></figure>
                  </div>
               </div>
               <div class="col-md-2 col-sm-5">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/logo10.jpg" alt="#"/></figure>
                  </div>
               </div>
               <div class="col-md-2 col-sm-5">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/logo11.jpg" alt="#"/></figure>
                  </div>
               </div>
                <div class="col-md-2 col-sm-5">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/logo12.jpg" alt="#"/></figure>
                  </div>
               </div>
                <div class="col-md-2 col-sm-5">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/logo13.jpg" alt="#"/></figure>
                  </div>
               </div>
                <div class="col-md-2 col-sm-5">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/logo14.jpg" alt="#"/></figure>
                  </div>
               </div>  <div class="col-md-2 col-sm-5">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/logo15.jpg" alt="#"/></figure>
                  </div>
               </div>
               <div class="col-md-2 col-sm-5">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/logo16.jpg" alt="#"/></figure>
                  </div>
               </div>
               <div class="col-md-2 col-sm-5">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/logo17.jpg" alt="#"/></figure>
                  </div>
               </div>
               <div class="col-md-2 col-sm-5">
                  <div class="gallery_img">
                     <figure><img src="assets_front/images/logo18.jpg" alt="#"/></figure>
                  </div>
               </div>
            </div>
         </div>
      </div>



<br>

      <!--  contact -->
      <div class="contact">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="titlepage">
                     <h2>Contact Us</h2>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-6">
                  <form id="request" class="main_form">
                     <div class="row">
                        <div class="col-md-12 ">
                           <input class="contactus" placeholder="Name" type="type" name="Name"> 
                        </div>
                        <div class="col-md-12">
                           <input class="contactus" placeholder="Email" type="type" name="Email"> 
                        </div>
                        <div class="col-md-12">
                           <input class="contactus" placeholder="Phone Number" type="type" name="Phone Number">                          
                        </div>
                        <div class="col-md-12">
                           <textarea class="textarea" placeholder="Message" type="type" Message="Name">Message</textarea>
                        </div>
                        <div class="col-md-12">
                           <button class="send_btn">Send</button>
                        </div>
                     </div>
                  </form>
               </div>
               <div class="col-md-6">
                  <div class="map_main">
                     <div class="map-responsive">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d905.0758612183282!2d67.0110655292496!3d24.853483715902644!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3eb33f7e509375eb%3A0x5110b169754b1729!2sGolden%20Plaza%20Pakistan%20Chowk!5e0!3m2!1sen!2s!4v1678403365575!5m2!1sen!2s" width="600" height="400" frameborder="0" style="border:0; width: 100%;" allowfullscreen=""></iframe>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>















<?php include('footer.php') ?>



