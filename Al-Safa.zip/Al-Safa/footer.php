<footer>
         <div class="footer">
            <div class="container">
               <div class="row">
                  <div class=" col-md-4">
                     <h3>Contact US</h3>
                     <ul class="conta">
                        <li><i class="fa fa-map-marker" aria-hidden="true"></i>Mezzanine Floor ,  Office # M-1<br> Golden Plaza near Super Biryani House, Pakistan Chowk Karachi.</li>
                        <li><i class="fa fa-mobile" aria-hidden="true"></i> +92 3333076963 </li>
                        <li> <i class="fa fa-envelope" aria-hidden="true"></i><a href="#"> psservicess582@gmail.com</a></li>
                     </ul>
                  </div>
                  <div class="col-md-4">
                     <h3>Menu Link</h3>
                     <ul class="link_menu">
                        <li class="active"><a href="index.php">Home</a></li>
                        <li><a href="Aboutus.php">About</a></li>
                        <li><a href="room.html">Services</a></li>
                        <li><a href="gallery.html">Portfolio</a></li>
                        <li><a href="blog.html">Blog</a></li>
                        <li><a href="Contact.php">Contact Us</a></li>
                     </ul>
                  </div>
                  <div class="col-md-4">
                     <h3>News letter</h3>
                     <form class="bottom_form">
                        <input class="enter" placeholder="Enter your email" type="text" name="Enter your email">
                        <button class="sub_btn">subscribe</button>
                     </form>
                     <ul class="social_icon">
                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                        <li><a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                     </ul>
                  </div>
               </div>
            </div>
        

         <div class="copyright">
               <div class="container">
                  <div class="row">
                     <div class="col-md-10 offset-md-1">
                        
                        <p>
                        © 2023 All Rights Reserved. Design by <a href="https://html.design/"> M.Abid Hussain</a>
                     </div>
                  </div>
               </div>
            </div>

      </footer>
      <!-- end footer -->
      <!-- Javascript files-->
      <script src="assets_front/js/jquery.min.js"></script>
      <script src="assets_front/js/bootstrap.bundle.min.js"></script>
      <script src="assets_front/js/jquery-3.0.0.min.js"></script>
      <!-- sidebar -->
      <script src="assets_front/js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="assets_front/js/custom.js"></script>
   </body>
</html>