<?php include('header.php') ?>

<br><br>


    <div class="back_re">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="title">
                      <h2>Our Services</h2>
                  </div>
               </div>
            </div>
         </div>
      </div>
       <div  class="our_room">
         <div class="container">
            <div class="row">
            	
               <div class="col-md-4 col-sm-6">
                  <div id="serv_hover"  class="room">
                     <div class="room_img">
                        <figure><img src="assets_front/images/offset.jpg" alt="#"/></figure>
                     </div>
                     <div class="bed_room">
                        <h3>OFFSET PRINTING</h3>
                        <p>Offset printing is a widely used printing method that produces high-quality prints with sharp details and vibrant colors.</p>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6">
                  <div id="serv_hover"  class="room">
                     <div class="room_img">
                        <figure><img src="assets_front/images/digital.jpg" alt="#"/></figure>
                     </div>
                     <div class="bed_room">
                        <h3>DIGITAL PRINTING</h3>
                        <p>Digital printing services are a great way to create high-quality prints quickly and efficiently for marketing or personal prints.</p>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6">
                  <div id="serv_hover"  class="room">
                     <div class="room_img">
                        <figure><img src="assets_front/images/screen.jpg" alt="#"/></figure>
                     </div>
                     <div class="bed_room">
                        <h3>SCREEN PRINTING</h3>
                        <p>Screen printing method can be used on a variety of materials, including paper, fabric, and plastics, and can create designs with vivid colors. </p>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6">
                  <div id="serv_hover"  class="room">
                     <div class="room_img">
                        <figure><img src="assets_front/images/fabric1.jpg" alt="#"/></figure>
                     </div>
                     <div class="bed_room">
                        <h3>FABRIC PRINTING</h3>
                        <p>Fabric printing services are a great way to create custom textiles for a variety of purposes, such as clothing, home decor, and accessories.</p>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6">
                  <div id="serv_hover"  class="room">
                     <div class="room_img">
                        <figure><img src="assets_front/images/mugshirt.jpg" alt="#"/></figure>
                     </div>
                     <div class="bed_room">
                        <h3>SHIRT & MUG PRINTING</h3>
                        <p>Mug and shirt printing services offer a unique and customizable way to express your personality and promote your brand.</p>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6">
                  <div id="serv_hover"  class="room">
                     <div class="room_img">
                        <figure><img src="assets_front/images/packaging.jpg" alt="#"/></figure>
                     </div>
                     <div class="bed_room">
                        <h3>PACKAGING SOLUTIONS</h3>
                        <p>Packaging solutions can help businesses reinforce their brand image by creating packaging that aligns with their overall branding. </p>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6">
                  <div id="serv_hover"  class="room">
                     <div class="room_img">
                        <figure><img src="assets_front/images/general.jpg" alt="#"/></figure>
                     </div>
                     <div class="bed_room">
                        <h3>GENERAL ORDER SUPPLY</h3>
                        <p>General order suppliers include anything from stationery equipment to office supplies, cleaning supplies, and even industrial equipment.</p>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6">
                  <div id="serv_hover"  class="room">
                     <div class="room_img">
                        <figure><img src="assets_front/images/files.jpg" alt="#"/></figure>
                     </div>
                     <div class="bed_room">
                        <h3>FILES MANUFACTURING</h3>
                        <p>Manufacturing files typically contain important information related to the production process including quality control and various types of products.</p>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6">
                  <div id="serv_hover"  class="room">
                     <div class="room_img">
                        <figure><img src="assets_front/images/record.jpg" alt="#"/></figure>
                     </div>
                     <div class="bed_room">
                        <h3>RECORD & BINDING</h3>
                        <p>Office record archive and binding are essential for any organization that wants to keep its important documents organized and accessible.</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      


<?php include('footer.php') ?>